export const handler = async event => {
    console.log('Received event:', JSON.stringify(event, null, 2));
    event.response.autoConfirmUser = true;    
    return event;
};