export const handler = async event => {
    console.log('Received event:', JSON.stringify(event));    
    event.response.issueTokens = true;
    event.response.failAuthentication = false;
    return event;
};